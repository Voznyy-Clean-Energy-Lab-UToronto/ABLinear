
import shutil
import os
from pathlib import Path

RECOMMENDED_PAW = {
    "H": "H",
    "He": "He",
    "Li": "Li_sv",
    "Be": "Be_sv",
    "B": "B",
    "C": "C",
    "N": "N",
    "O": "O",
    "F": "F",
    "Ne": "Ne",
    "Na": "Na_pv",
    "Mg": "Mg",
    "Al": "Al",
    "Si": "Si",
    "P": "P",
    "S": "S",
    "Cl": "Cl",
    "Ar": "Ar",
    "K": "K_sv",
    "Ca": "Ca_sv",
    "Sc": "Sc_sv",
    "Ti": "Ti_pv",
    "V": "V_pv",
    "Cr": "Cr_pv",
    "Mn": "Mn_pv",
    "Fe": "Fe_pv",
    "Co": "Co_pv",
    "Ni": "Ni_pv",
    "Cu": "Cu_pv",
    "Zn": "Zn",
    "Ga": "Ga_d",
    "Ge": "Ge_d",
    "As": "As",
    "Se": "Se",
    "Br": "Br",
    "Kr": "Kr",
    "Rb": "Rb_sv",
    "Sr": "Sr_sv",
    "Y": "Y_sv",
    "Zr": "Zr_sv",
    "Nb": "Nb_pv",
    "Mo": "Mo_pv",
    "Tc": "Tc_pv",
    "Ru": "Ru_pv",
    "Rh": "Rh_pv",
    "Pd": "Pd_pv",
    "Ag": "Ag_pv",
    "Cd": "Cd",
    "In": "In_d",
    "Sn": "Sn_d",
    "Sb": "Sb",
    "Te": "Te",
    "I": "I",
    "Xe": "Xe",
    "Cs": "Cs_sv",
    "Ba": "Ba_sv",
    "La": "La",
    "Ce": "Ce",
    "Hf": "Hf_pv",
    "Ta": "Ta_pv",
    "W": "W_sv",
    "Re": "Re_pv",
    "Os": "Os_pv",
    "Ir": "Ir",
    "Pt": "Pt_pv",
    "Au": "Au",
    "Hg": "Hg",
    "Tl": "Tl_d",
    "Pb": "Pb_d",
    "Bi": "Bi_d",
    "Po": "Po_d",
    "At": "At",
    "Rn": "Rn",
    "Fr": "Fr_sv",
    "Ra": "Ra_sv",
    "Ac": "Ac",
    "Th": "Th",
    "Pa": "Pa",
    "U": "U",
    "Np": "Np",
    "Pu": "Pu"
}

potcarpath = Path(os.path.expanduser("~/Prog/VASP/PSP/POT_GGA_PAW_PBE"))

def parse_species(poscar_file):
    with open(poscar_file, 'r') as f:
        lines = f.readlines()
    return lines[5].split()

def generate_potcar(species, output_path):
    with open(output_path, "wb") as out:
        for element in species:
            paw_label = RECOMMENDED_PAW.get(element)
            if not paw_label:
                raise ValueError(f"No recommended PAW found for {element}")
            potcar_dir = potcarpath / "POTCAR.{}".format(paw_label)
            if not potcar_dir.exists():
                raise FileNotFoundError(f"POTCAR not found: {potcar_dir}")
            with open(potcar_dir, "rb") as f:
                out.write(f.read())

def main():
    cwd = Path(".")
    incar = cwd / "INCAR"
    kpoints = cwd / "KPOINTS"
    
    if not incar.exists() or not kpoints.exists():
        print("Missing INCAR or KPOINTS.")
        return

    for contcar in cwd.glob("*.CONTCAR"):
        try:
            species = parse_species(contcar)
            #species_sorted = sorted(species)
            folder_name = "_".join(species)
            folder = cwd / folder_name
            folder.mkdir(exist_ok=True)

            # Move files
            shutil.copy(contcar, folder / "POSCAR")
            shutil.copy(incar, folder / "INCAR")
            shutil.copy(kpoints, folder / "KPOINTS")
            with open(folder / "{}.inp".format(folder_name), "w") as f:
                f.write(f"{folder_name}\n")

            # Write PAW info
            with open(folder / "paw_recommendation.txt", "w") as f:
                f.write("Atoms: " + ", ".join(species) + "\n")
                for s in species:
                    paw = RECOMMENDED_PAW.get(s, "UNKNOWN")
                    f.write(f"  {s}: {paw}\n")

            # Generate POTCAR
            generate_potcar(species, folder / "POTCAR")

            print(f"[✓] {contcar.name} → {folder_name}/ with POTCAR")

        except Exception as e:
            print(f"[!] Error processing {contcar.name}: {e}")

if __name__ == "__main__":
    main()