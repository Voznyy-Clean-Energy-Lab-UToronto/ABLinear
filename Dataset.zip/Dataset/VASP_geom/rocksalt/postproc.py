
import re
import os

def get_gamma_gap(filename):
    """Get the band gap at the first k-point from EIGENVAL."""
    with open(filename) as f:
        lines = f.readlines()
    num_kpoints = int(lines[5].split()[1])
    num_bands = int(lines[5].split()[2])

    # The first k-point block starts after line 6.
    line_index = 7
    bands = []
    for b in range(num_bands):
        vals = lines[line_index + b].split()
        energy = float(vals[1])
        occ = float(vals[2])
        bands.append((energy, occ))

    vbm = max(energy for energy, occ in bands if occ > 0.0)
    cbm = min(energy for energy, occ in bands if occ == 0.0)
    return cbm - vbm


if __name__ == "__main__":
    root_dir = os.getcwd()
    results = []
    for name in os.listdir(root_dir):
        if os.path.isdir(name) and os.path.isfile(os.path.join(name, "EIGENVAL")):
            gap = get_gamma_gap(os.path.join(name, "EIGENVAL"))
            results.append((name, gap))

    # Print results
    for structure, gap in sorted(results):
        print(f"{structure}: {gap:.3f} eV")

    # Optional: Save to a file
    with open("gamma_gaps.csv", "w") as f:
        for structure, gap in sorted(results):
            f.write(f"{structure},{gap:.12f}\n")