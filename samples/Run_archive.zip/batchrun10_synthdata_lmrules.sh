#!/bin/bash

for i in `seq 1 10`
do

	# ( jobname=20_dsplit_lmrules_rsonly_${i}_for; python3 ABlinear_nn.py . --id-prop-t synthdata_overlaps/lm_dsplit/20train_rsonly_${i}.csv --id-prop-v synthdata_overlaps/lm_dsplit/20val_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "sp+valence1hot+row+block" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

	# ( jobname=20_dsplit_lmrules_zb1_${i}_for; python3 ABlinear_nn.py . --id-prop-t synthdata_overlaps/lm_dsplit/20train_mpzb1_${i}.csv --id-prop-v synthdata_overlaps/lm_dsplit/20val_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "sp+valence1hot+row+block" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

	# ( jobname=20_dsplit_lmrules_zb2_${i}_for; python3 ABlinear_nn.py . --id-prop-t synthdata_overlaps/lm_dsplit/20train_mpzb2_${i}.csv --id-prop-v synthdata_overlaps/lm_dsplit/20val_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "sp+valence1hot+row+block" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

	# ( jobname=20_dsplit_lmrules_matprojzb_${i}_for; python3 ABlinear_nn.py . --id-prop-t synthdata_overlaps/lm_dsplit/20train_mpzb_all_${i}.csv --id-prop-v synthdata_overlaps/lm_dsplit/20val_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "sp+valence1hot+row+block" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 

	# ( jobname=20_dsplit_lmrules_zb_allcombs_${i}_for; python3 ABlinear_nn.py . --id-prop-t synthdata_overlaps/lm_dsplit/20train_zb_allcombs_${i}.csv --id-prop-v synthdata_overlaps/lm_dsplit/20val_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "sp+valence1hot+row+block" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	# #allcombs
	# ( jobname=20_dsplit_lmrules_allcomb_rsonly_${i}_for; python3 ABlinear_nn.py . --id-prop-t synthdata_overlaps/lm_dsplit/20train_allcomb_rsonly_${i}.csv --id-prop-v synthdata_overlaps/lm_dsplit/20val_allcomb_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "sp+valence1hot+row+block" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

	( jobname=20_dsplit_lmrules_allcomb_zb1_${i}_for; python3 ABlinear_nn.py . --id-prop-t synthdata_overlaps/lm_dsplit/20train_allcomb_mpzb1_${i}.csv --id-prop-v synthdata_overlaps/lm_dsplit/20val_allcomb_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "sp+valence1hot+row+block" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 

	( jobname=20_dsplit_lmrules_allcomb_zb2_${i}_for; python3 ABlinear_nn.py . --id-prop-t synthdata_overlaps/lm_dsplit/20train_allcomb_mpzb2_${i}.csv --id-prop-v synthdata_overlaps/lm_dsplit/20val_allcomb_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "sp+valence1hot+row+block" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 

	( jobname=20_dsplit_lmrules_allcomb_matprojzb_${i}_for; python3 ABlinear_nn.py . --id-prop-t synthdata_overlaps/lm_dsplit/20train_allcomb_mpzb_all_${i}.csv --id-prop-v synthdata_overlaps/lm_dsplit/20val_allcomb_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "sp+valence1hot+row+block" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 

	( jobname=20_dsplit_lmrules_allcomb_zb_allcombs_${i}_for; python3 ABlinear_nn.py . --id-prop-t synthdata_overlaps/lm_dsplit/20train_allcomb_zb_allcombs_${i}.csv --id-prop-v synthdata_overlaps/lm_dsplit/20val_allcomb_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "sp+valence1hot+row+block" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 

done


