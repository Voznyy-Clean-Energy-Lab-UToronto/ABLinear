#!/bin/bash

( jobname=rocksalt_allvasp_dsplit0_spvalrowblock_lrlo_wdhi_allcombs; python3 ABlinear_nn.py . --id-prop-t rocksalts/dsplit2/d0_rs.csv --id-prop-v rocksalts/dsplit2/d0_rs.csv --out $jobname --width 797 --funnel 2 -m 8 -e 50000 --ari "sp+valence1hot+row+block" --lr 1e-6 --wd 1e-3  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

( jobname=zincblende_allvasp_dsplit0_spvalrowblock_lrlo_wdhi_allcombs; python3 ABlinear_nn.py . --id-prop-t rocksalts/dsplit2/d0.csv --id-prop-v rocksalts/dsplit2/d0.csv --out $jobname --width 797 --funnel 2 -m 8 -e 50000 --ari "sp+valence1hot+row+block" --lr 1e-6 --wd 1e-3  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )

( jobname=rocksalt_allvasp_dsplit1_spvalrowblock_lrlo_wdhi_allcombs; python3 ABlinear_nn.py . --id-prop-t rocksalts/dsplit2/d1_rs.csv --id-prop-v rocksalts/dsplit2/d1_rs.csv --out $jobname --width 797 --funnel 2 -m 8 -e 50000 --ari "sp+valence1hot+row+block" --lr 1e-6 --wd 1e-3  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

( jobname=zincblende_allvasp_dsplit1_spvalrowblock_lrlo_wdhi_allcombs; python3 ABlinear_nn.py . --id-prop-t rocksalts/dsplit2/d1.csv --id-prop-v rocksalts/dsplit2/d1.csv --out $jobname --width 797 --funnel 2 -m 8 -e 50000 --ari "sp+valence1hot+row+block" --lr 1e-6 --wd 1e-3  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )

( jobname=rocksalt_allvasp_dsplit2_spvalrowblock_lrlo_wdhi_allcombs; python3 ABlinear_nn.py . --id-prop-t rocksalts/dsplit2/d2_rs.csv --id-prop-v rocksalts/dsplit2/d2_rs.csv --out $jobname --width 797 --funnel 2 -m 8 -e 50000 --ari "sp+valence1hot+row+block" --lr 1e-6 --wd 1e-3  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

( jobname=zincblende_allvasp_dsplit2_spvalrowblock_lrlo_wdhi_allcombs; python3 ABlinear_nn.py . --id-prop-t rocksalts/dsplit2/d2.csv --id-prop-v rocksalts/dsplit2/d2.csv --out $jobname --width 797 --funnel 2 -m 8 -e 50000 --ari "sp+valence1hot+row+block" --lr 1e-6 --wd 1e-3  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )


