#!/bin/bash

for i in `seq 1 10`
do

	( jobname=_5mpgamma_20_dft_poscarorb_rsonly_${i}_for; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_mpgamma/20train_rsonly_${i}.csv --id-prop-v rocksalts/acdft_mpgamma/20val_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 20000 --ari "potcarorb+eneg+hard+1hrow+block+1hvalence" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

	( jobname=_5mpgamma_20_dft_poscarorb_matprojzb_${i}_for; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_mpgamma/20train_mpzb_${i}.csv --id-prop-v rocksalts/acdft_mpgamma/20val_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 20000 --ari "potcarorb+eneg+hard+1hrow+block+1hvalence" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	( jobname=_5mpgamma_20_dft_poscarorb_allzb_${i}_for; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_mpgamma/20train_allcombzb_${i}.csv --id-prop-v rocksalts/acdft_mpgamma/20val_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 20000 --ari "potcarorb+eneg+hard+1hrow+block+1hvalence" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 
	
	
	( jobname=_5mpgamma_20_dft_poscarorb_allcomb_rsonly_${i}_for; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_mpgamma/20train_allcomb_rsonly_${i}.csv --id-prop-v rocksalts/acdft_mpgamma/20val_allcomb_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 20000 --ari "potcarorb+eneg+hard+1hrow+block+1hvalence" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

	( jobname=_5mpgamma_20_dft_poscarorb_allcomb_matprojzb_${i}_for; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_mpgamma/20train_allcomb_mpzb_${i}.csv --id-prop-v rocksalts/acdft_mpgamma/20val_allcomb_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 20000 --ari "potcarorb+eneg+hard+1hrow+block+1hvalence" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	( jobname=_5mpgamma_20_dft_poscarorb_allcomb_allzb_${i}_for; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_mpgamma/20train_allcomb_allcombzb_${i}.csv --id-prop-v rocksalts/acdft_mpgamma/20val_allcomb_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 20000 --ari "potcarorb+eneg+hard+1hrow+block+1hvalence" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 

done




