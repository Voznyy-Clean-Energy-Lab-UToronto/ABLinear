#!/bin/bash


for i in `seq 1 10`
do

	( jobname=4vaspreoptresplit2_20_dft_poscarorb+wierd_rsonly_${i}_for; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_rsonly_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 20000 --ari "potcarorb+eneg+hard+1hrow+block+1hvalence+wierd" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

	( jobname=4vaspreoptresplit2_20_dft_poscarorb+wierd_matprojzb_${i}_for; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_mpzb_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 20000 --ari "potcarorb+eneg+hard+1hrow+block+1hvalence+wierd" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	( jobname=4vaspreoptresplit2_20_dft_poscarorb+wierd_allzb_${i}_for; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_allcombzb_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 20000 --ari "potcarorb+eneg+hard+1hrow+block+1hvalence+wierd" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 
	
	
	( jobname=4vaspreoptresplit2_20_dft_poscarorb+wierd_allcomb_rsonly_${i}_for; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_allcomb_rsonly_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_allcomb_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 20000 --ari "potcarorb+eneg+hard+1hrow+block+1hvalence+wierd" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

	( jobname=4vaspreoptresplit2_20_dft_poscarorb+wierd_allcomb_matprojzb_${i}_for; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_allcomb_mpzb_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_allcomb_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 20000 --ari "potcarorb+eneg+hard+1hrow+block+1hvalence+wierd" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	( jobname=4vaspreoptresplit2_20_dft_poscarorb+wierd_allcomb_allzb_${i}_for; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_allcomb_allcombzb_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_allcomb_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 20000 --ari "potcarorb+eneg+hard+1hrow+block+1hvalence+wierd" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 

done


for i in `seq 1 10`
do

	( jobname=4vaspreoptresplit2_50_dft_poscarorb+wierd_rsonly_${i}_for; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/50train_rsonly_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/50val_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "potcarorb+eneg+hard+1hrow+block+1hvalence+wierd" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

	( jobname=4vaspreoptresplit2_50_dft_poscarorb+wierd_matprojzb_${i}_for; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/50train_mpzb_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/50val_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "potcarorb+eneg+hard+1hrow+block+1hvalence+wierd" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	( jobname=4vaspreoptresplit2_50_dft_poscarorb+wierd_allzb_${i}_for; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/50train_allcombzb_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/50val_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "potcarorb+eneg+hard+1hrow+block+1hvalence+wierd" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 
	
	
	( jobname=4vaspreoptresplit2_50_dft_poscarorb+wierd_allcomb_rsonly_${i}_for; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/50train_allcomb_rsonly_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/50val_allcomb_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "potcarorb+eneg+hard+1hrow+block+1hvalence+wierd" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

	( jobname=4vaspreoptresplit2_50_dft_poscarorb+wierd_allcomb_matprojzb_${i}_for; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/50train_allcomb_mpzb_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/50val_allcomb_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "potcarorb+eneg+hard+1hrow+block+1hvalence+wierd" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	( jobname=4vaspreoptresplit2_50_dft_poscarorb+wierd_allcomb_allzb_${i}_for; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/50train_allcomb_allcombzb_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/50val_allcomb_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "potcarorb+eneg+hard+1hrow+block+1hvalence+wierd" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 

done