#!/bin/bash


for i in `seq 1 10`
do

	( jobname=5vaspreoptresplit2_20_dft_onehot_rsonly_${i}_conv; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_rsonly_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 1 -e 20000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

	( jobname=5vaspreoptresplit2_20_dft_onehot_matprojzb_${i}_conv; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_mpzb_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 1 -e 20000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	( jobname=5vaspreoptresplit2_20_dft_onehot_allzb_${i}_conv; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_allcombzb_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 1 -e 20000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 
	
	
	( jobname=5vaspreoptresplit2_20_dft_onehot_allcomb_rsonly_${i}_conv; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_allcomb_rsonly_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_allcomb_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 1 -e 20000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

	( jobname=5vaspreoptresplit2_20_dft_onehot_allcomb_matprojzb_${i}_conv; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_allcomb_mpzb_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_allcomb_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 1 -e 20000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	( jobname=5vaspreoptresplit2_20_dft_onehot_allcomb_allzb_${i}_conv; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_allcomb_allcombzb_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_allcomb_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 1 -e 20000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 

done


for i in `seq 1 10`
do

	( jobname=5vaspreoptresplit2_20_dft_onehot_rsonly_${i}_pconv; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_rsonly_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 2 -e 20000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

	( jobname=5vaspreoptresplit2_20_dft_onehot_matprojzb_${i}_pconv; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_mpzb_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 2 -e 20000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	( jobname=5vaspreoptresplit2_20_dft_onehot_allzb_${i}_pconv; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_allcombzb_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 2 -e 20000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 
	
	
	( jobname=5vaspreoptresplit2_20_dft_onehot_allcomb_rsonly_${i}_pconv; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_allcomb_rsonly_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_allcomb_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 2 -e 20000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

	( jobname=5vaspreoptresplit2_20_dft_onehot_allcomb_matprojzb_${i}_pconv; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_allcomb_mpzb_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_allcomb_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 2 -e 20000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	( jobname=5vaspreoptresplit2_20_dft_onehot_allcomb_allzb_${i}_pconv; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_allcomb_allcombzb_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_allcomb_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 2 -e 20000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 

done

for i in `seq 1 10`
do

	( jobname=5vaspreoptresplit2_20_dft_onehot_rsonly_${i}_pool; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_rsonly_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 7 -e 20000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

	( jobname=5vaspreoptresplit2_20_dft_onehot_matprojzb_${i}_pool; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_mpzb_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 7 -e 20000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	( jobname=5vaspreoptresplit2_20_dft_onehot_allzb_${i}_pool; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_allcombzb_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 7 -e 20000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 
	
	
	( jobname=5vaspreoptresplit2_20_dft_onehot_allcomb_rsonly_${i}_pool; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_allcomb_rsonly_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_allcomb_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 7 -e 20000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

	( jobname=5vaspreoptresplit2_20_dft_onehot_allcomb_matprojzb_${i}_pool; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_allcomb_mpzb_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_allcomb_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 7 -e 20000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	( jobname=5vaspreoptresplit2_20_dft_onehot_allcomb_allzb_${i}_pool; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_allcomb_allcombzb_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_allcomb_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 7 -e 20000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 

done


for i in `seq 1 10`
do

	( jobname=5vaspreoptresplit2_20_dft_onehot_rsonly_${i}_gnn; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_rsonly_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 4 -e 20000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

	( jobname=5vaspreoptresplit2_20_dft_onehot_matprojzb_${i}_gnn; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_mpzb_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 4 -e 20000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	( jobname=5vaspreoptresplit2_20_dft_onehot_allzb_${i}_gnn; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_allcombzb_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 4 -e 20000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 
	
	
	( jobname=5vaspreoptresplit2_20_dft_onehot_allcomb_rsonly_${i}_gnn; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_allcomb_rsonly_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_allcomb_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 4 -e 20000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

	( jobname=5vaspreoptresplit2_20_dft_onehot_allcomb_matprojzb_${i}_gnn; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_allcomb_mpzb_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_allcomb_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 4 -e 20000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	( jobname=5vaspreoptresplit2_20_dft_onehot_allcomb_allzb_${i}_gnn; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_allcomb_allcombzb_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_allcomb_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 4 -e 20000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 

done

for i in `seq 1 10`
do

	( jobname=5vaspreoptresplit2_20_dft_onehot_rsonly_${i}_gpool; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_rsonly_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 9 -e 20000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

	( jobname=5vaspreoptresplit2_20_dft_onehot_matprojzb_${i}_gpool; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_mpzb_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 9 -e 20000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	( jobname=5vaspreoptresplit2_20_dft_onehot_allzb_${i}_gpool; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_allcombzb_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 9 -e 20000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 
	
	
	( jobname=5vaspreoptresplit2_20_dft_onehot_allcomb_rsonly_${i}_gpool; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_allcomb_rsonly_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_allcomb_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 9 -e 20000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

	( jobname=5vaspreoptresplit2_20_dft_onehot_allcomb_matprojzb_${i}_gpool; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_allcomb_mpzb_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_allcomb_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 9 -e 20000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	( jobname=5vaspreoptresplit2_20_dft_onehot_allcomb_allzb_${i}_gpool; python3 ABlinear_nn.py . --id-prop-t rocksalts/acdft_reopt/resplit2/20train_allcomb_allcombzb_${i}.csv --id-prop-v rocksalts/acdft_reopt/resplit2/20val_allcomb_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 9 -e 20000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 

done