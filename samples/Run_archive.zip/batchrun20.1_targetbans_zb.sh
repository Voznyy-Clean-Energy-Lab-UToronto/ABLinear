#!/bin/bash


declare -a targets=( "FLi" "FAg" "NAl" "NGa" "OBe" "OMg" "NB" "PB")

for i in "${targets[@]}"
do
	echo $i
	( jobname=9zb_vaspreoptresplit_soft_dft_poscarorb+wierd_ban${i}_for; python3 ABlinear_nn.py . --id-prop-t zincblendes/targetbans/train_${i}.csv --id-prop-v zincblendes/targetbans/val_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 20000 --ari "potcarorb+eneg+hard+1hrow+block+1hvalence+wierd" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )

done
