#!/bin/bash

( jobname=zbvsrs_soft_20_dft_poscarorb+wierd_allcomb_rsonly_${i}_for; python3 ABlinear_nn.py . --id-prop-t zincblendes/vasp_rs.csv --id-prop-v zincblendes/vasp_zb.csv --out $jobname --width 797 --funnel 2 -m 0 -e 20000 --ari "potcarorb+eneg+hard+1hrow+block+1hvalence+wierd" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )
