#!/bin/bash


declare -a targets=( "Li_F" "Ag_F" "Al_N" "Ga_N" "Be_O" "Mg_O" "B_N" "B_P" "Al_P")

for i in "${targets[@]}"
do
	echo $i
	( jobname=13zb_vaspreoptresplit_hard_dft_covaloh_ban${i}_for; python3 ABlinear_nn.py . --id-prop-t zincblendes/zb_lattparam/targetbans/train_${i}.csv --id-prop-v zincblendes/zb_lattparam/targetbans/val_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 100000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )

done
