#!/bin/bash


for i in `seq 1 20`
do

	( jobname=13zb_vaspbnfix_20_dft_covaloh_rsonly_${i}_for; python3 ABlinear_nn.py . --id-prop-t zincblendes/zb_lattparam/20train_rsonly_${i}.csv --id-prop-v zincblendes/zb_lattparam/20val_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 20000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	( jobname=13zb_vaspbnfix_20_dft_covaloh_allcomb_rsonly_${i}_for; python3 ABlinear_nn.py . --id-prop-t zincblendes/zb_lattparam/20train_allcomb_rsonly_${i}.csv --id-prop-v zincblendes/zb_lattparam/20val_allcomb_rsonly_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 20000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 

	( jobname=13zb_vaspbnfix_20_dft_covaloh_allcomb_rsonly_${i}_for; python3 ABlinear_pred.py . --id-prop-p zincblendes/zb_lattparam/vasp_zb.csv --out $jobname --width 797 --funnel 2 -m 0 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	( jobname=13zb_vaspbnfix_20_dft_covaloh_rsonly_${i}_for; python3 ABlinear_pred.py . --id-prop-p zincblendes/zb_lattparam/vasp_zb.csv --out $jobname --width 797 --funnel 2 -m 0 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 
done
