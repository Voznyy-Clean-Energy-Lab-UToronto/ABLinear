#!/bin/bash

#( jobname=15_2atm_70_t5o_anneal0-500_w400_for; python3 ABlinear_nn.py . --id-prop-t 2atmcombstruct/30train_2atm_10.csv --id-prop-v 2atmcombstruct/30val_cc_10.csv --out $jobname --width 400 --funnel 2 -m 0 -e 100000 --ari "top5orb" --lr 6e-3 --wd 2e-4 --anneal-min 0 --anneal-len 500 > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 

( jobname=18_2atm_70_t5on_vvl10_for; python3 ABlinear_nn.py . --id-prop-t 2atmcombstruct/30train_2atm_10.csv --id-prop-v 2atmcombstruct/30val_cc_10.csv --out $jobname --width 797 --funnel 2 -m 0 -e 1000000 --ari "top5orb" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )