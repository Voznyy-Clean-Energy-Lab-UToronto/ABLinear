#!/bin/bash


declare -a targets=( "FLi" "FAg" "NAl" "NGa" "OBe" "OMg" "NB" "PB" "PAl")

for i in "${targets[@]}"
do
	echo $i
	( jobname=17zb_20_top5orb_nobondlen2_ban${i}_for; python3 ABlinear_nn.py . --id-prop-t zincblendes/targetbans/train_${i}.csv --id-prop-v zincblendes/targetbans/val_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 100000 --ari "top5orb" --lr 6e-3 --wd 2e-4 --anneal-min 0 --anneal-len 500 > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )

done
