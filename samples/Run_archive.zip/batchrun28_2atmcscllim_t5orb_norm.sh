#!/bin/bash


for i in `seq 1 10`
do

	( jobname=18_2atm_90_t10on_${i}_for; python3 ABlinear_nn.py . --id-prop-t 2atmcombstruct/10train_2atm_${i}.csv --id-prop-v 2atmcombstruct/10val_cc_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 100000 --ari "top10orb_n" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	( jobname=18_2atm_80_t10on_${i}_for; python3 ABlinear_nn.py . --id-prop-t 2atmcombstruct/20train_2atm_${i}.csv --id-prop-v 2atmcombstruct/20val_cc_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 100000 --ari "top10orb_n" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	( jobname=18_2atm_70_t10on_${i}_for; python3 ABlinear_nn.py . --id-prop-t 2atmcombstruct/30train_2atm_${i}.csv --id-prop-v 2atmcombstruct/30val_cc_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 100000 --ari "top10orb_n" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 
done
