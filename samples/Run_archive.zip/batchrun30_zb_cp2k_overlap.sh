#!/bin/bash


for i in `seq 1 10`
do
	( jobname=20_zb_cp2koverlap_t10_${i}_for; python3 ABlinear_nn.py . --id-prop-t 2atmcombstruct/cp2koverlap/80zb_train_${i}.csv --id-prop-v 2atmcombstruct/cp2koverlap/80zb_val_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 
done
