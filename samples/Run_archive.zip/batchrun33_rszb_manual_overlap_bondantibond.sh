#!/bin/bash


for i in `seq 1 10`
do
	( jobname=25_rszb_ov_sgr_rsonly_${i}_for; python3 ABlinear_nn.py . --id-prop-t 2atmcombstruct/manoverlap/80rsonly_train_${i}.csv --id-prop-v 2atmcombstruct/manoverlap/80rs_val_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "s_group_row" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	( jobname=25_rszb_ov_sgr_rszb_${i}_for; python3 ABlinear_nn.py . --id-prop-t 2atmcombstruct/manoverlap/80rszb_train_${i}.csv --id-prop-v 2atmcombstruct/manoverlap/80rs_val_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "s_group_row" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	( jobname=25_zb_ov_sgr_${i}_for; python3 ABlinear_nn.py . --id-prop-t 2atmcombstruct/manoverlap/80zb_train_${i}.csv --id-prop-v 2atmcombstruct/manoverlap/80zb_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 0 -e 50000 --ari "s_group_row" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 
	
	# ( jobname=25_rszb_ovbl_onehot_rsonly_${i}_for; python3 ABlinear_nn.py . --id-prop-t 2atmcombstruct/overlap_bondlen/80rsonly_train_${i}.csv --id-prop-v 2atmcombstruct/overlap_bondlen/80rs_val_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	# ( jobname=25_rszb_ovbl_onehot_rszb_${i}_for; python3 ABlinear_nn.py . --id-prop-t 2atmcombstruct/overlap_bondlen/80rszb_train_${i}.csv --id-prop-v 2atmcombstruct/overlap_bondlen/80rs_val_${i}.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	# ( jobname=25_zb_ovbl_onehot_${i}_for; python3 ABlinear_nn.py . --id-prop-t 2atmcombstruct/overlap_bondlen/80zb_train_${i}.csv --id-prop-v 2atmcombstruct/overlap_bondlen/80zb_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 0 -e 50000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )
done
