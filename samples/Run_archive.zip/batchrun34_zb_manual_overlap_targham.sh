#!/bin/bash


for i in `seq 1 10`
do
	( jobname=26_zb_hamtarg_1hot_w100wd2e-6_${i}_for; python3 ABlinear_nn.py . --id-prop-t ss_overlap/hamiltonian/80zb_train_${i}.csv --id-prop-v ss_overlap/hamiltonian/80zb_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 0 -e 50000 --ari "onehot" --lr 6e-3 --wd 2e-6  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 
done