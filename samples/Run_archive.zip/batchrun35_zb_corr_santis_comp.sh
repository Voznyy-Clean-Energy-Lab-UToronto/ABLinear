#!/bin/bash


for i in `seq 1 10`
do
	( jobname=27_zb_corrsantis_base_1hot_w100wd2e-3_${i}_for; python3 ABlinear_nn.py . --id-prop-t 2atmcombstruct/corr_santis/80zbb_train_${i}.csv --id-prop-v 2atmcombstruct/corr_santis/80zbb_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 0 -e 50000 --ari "onehot" --lr 6e-3 --wd 2e-3  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )& 
	
	( jobname=27_zb_corrsantis_overlap_1hot_w100wd2e-3_${i}_for; python3 ABlinear_nn.py . --id-prop-t 2atmcombstruct/corr_santis/80zba_train_${i}.csv --id-prop-v 2atmcombstruct/corr_santis/80zba_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 0 -e 50000 --ari "onehot" --lr 6e-3 --wd 2e-3  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	( jobname=27_zb_corrsantis_base_top10_w100wd2e-3_${i}_for; python3 ABlinear_nn.py . --id-prop-t 2atmcombstruct/corr_santis/80zbb_train_${i}.csv --id-prop-v 2atmcombstruct/corr_santis/80zbb_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-3 --wd 2e-3  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )& 
	
	( jobname=27_zb_corrsantis_overlap_top10_w100wd2e-3_${i}_for; python3 ABlinear_nn.py . --id-prop-t 2atmcombstruct/corr_santis/80zba_train_${i}.csv --id-prop-v 2atmcombstruct/corr_santis/80zba_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-3 --wd 2e-3  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )
	
done