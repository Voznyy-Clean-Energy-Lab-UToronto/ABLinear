#!/bin/bash


for i in `seq 1 10`
do
	( jobname=28_zb_lumo_s_12_1hot_w100wd2e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t 2atmcombstruct/lumo_s/80zb12_train_${i}.csv --id-prop-v 2atmcombstruct/lumo_s/80zb12_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 0 -e 50000 --ari "onehot" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )& 
	
	( jobname=28_zb_lumo_s_12_cp2ktop3_w100wd2e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t 2atmcombstruct/lumo_s/80zb12_train_${i}.csv --id-prop-v 2atmcombstruct/lumo_s/80zb12_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 0 -e 50000 --ari "cp2ktop3_only" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )& 
	
	( jobname=28_zb_lumo_s_12_cp2ktop3_covalradius_w100wd2e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t 2atmcombstruct/lumo_s/80zb12_train_${i}.csv --id-prop-v 2atmcombstruct/lumo_s/80zb12_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 0 -e 50000 --ari "cp2ktop3_coval" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )& 
	
	( jobname=28_zb_lumo_s_12_cp2ktop3_1hot_w100wd2e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t 2atmcombstruct/lumo_s/80zb12_train_${i}.csv --id-prop-v 2atmcombstruct/lumo_s/80zb12_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 0 -e 50000 --ari "cp2ktop3_1hot" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )
	
done