#!/bin/bash


for i in `seq 1 10`
do
	#( jobname=29_zb_lumo_s_ionic_offset_35_1hot_w100wd2e-5_${i}_lm; python3 ABlinear_nn.py . --id-prop-t lumo_s/80zba_train_${i}.csv --id-prop-v lumo_s/80zba_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 8 -e 50000 --ari "onehot" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )& 
	
	#( jobname=29_zb_lumo_s_ionic_offset_35_1hot_w100wd2e-6_${i}_lm; python3 ABlinear_nn.py . --id-prop-t lumo_s/80zba_train_${i}.csv --id-prop-v lumo_s/80zba_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 8 -e 50000 --ari "onehot" --lr 6e-3 --wd 2e-6  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )& 
	
	#( jobname=29_zb_lumo_s_ionic_offset_35_1hot_w100wd2e-4_${i}_lm; python3 ABlinear_nn.py . --id-prop-t lumo_s/80zba_train_${i}.csv --id-prop-v lumo_s/80zba_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 8 -e 50000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )
	
	#( jobname=29_zb_lumo_s_ionic_offset_1hot_w100wd2e-5_${i}_lm; python3 ABlinear_nn.py . --id-prop-t lumo_s/80zb_train_${i}.csv --id-prop-v lumo_s/80zb_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 8 -e 50000 --ari "onehot" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )& 
	
	#( jobname=29_zb_lumo_s_ionic_offset_1hot_w100wd2e-6_${i}_lm; python3 ABlinear_nn.py . --id-prop-t lumo_s/80zb_train_${i}.csv --id-prop-v lumo_s/80zb_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 8 -e 50000 --ari "onehot" --lr 6e-3 --wd 2e-6  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )& 
	
	#( jobname=29_zb_lumo_s_ionic_offset_1hot_w100wd2e-4_${i}_lm; python3 ABlinear_nn.py . --id-prop-t lumo_s/80zb_train_${i}.csv --id-prop-v lumo_s/80zb_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 8 -e 50000 --ari "onehot" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )
	
	( jobname=29_zb_lumo_s_ionic_offset_1hotgreneg_w100wd2e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t lumo_s/80zb_train_${i}.csv --id-prop-v lumo_s/80zb_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 0 -e 50000 --ari "1hotgreneg" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )& 
	( jobname=29_zb_lumo_s_ionic_offset_35_1hotgreneg_w100wd2e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t lumo_s/80zba_train_${i}.csv --id-prop-v lumo_s/80zba_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 0 -e 50000 --ari "1hotgreneg" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )
	
done
