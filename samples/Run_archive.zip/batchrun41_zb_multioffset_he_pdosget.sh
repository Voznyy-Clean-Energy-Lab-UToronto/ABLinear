#!/bin/bash


for i in `seq 1 20`
do

	( jobname=41_mzbai_cp2kgamma_Herelorb_1hot_w100wd2e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/He_ref/multitarg/80zbaig_train_${i}.csv --id-prop-v relative_orbs/He_ref/multitarg/80zbaig_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 0 -e 50000 --ari "onehot" --lr 6e-3 --wd 2e-5 --ntarg 3  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )& 
	
	( jobname=41_mzbai_cp2kgamma_Herelorb_1hotgreneg_w100wd2e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/He_ref/multitarg/80zbaig_train_${i}.csv --id-prop-v relative_orbs/He_ref/multitarg/80zbaig_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 0 -e 50000 --ari "1hotgreneg" --lr 6e-3 --wd 2e-5 --ntarg 3  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )& 
	
	( jobname=41_mzbai_cp2kgamma_Herelorb_vcebrg_w100wd2e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/He_ref/multitarg/80zbaig_train_${i}.csv --id-prop-v relative_orbs/He_ref/multitarg/80zbaig_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 0 -e 50000 --ari "valence_cradii_eneg_1hBlockRowGroup" --lr 6e-3 --wd 2e-5 --ntarg 3  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 

	
done