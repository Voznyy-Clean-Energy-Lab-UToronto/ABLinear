#!/bin/bash


for i in `seq 1 20`
do
	#current best
	#( jobname=58_pzb_ai_cp2kgamma_Herelorb_w100wd2e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/He_ref/80pzbaig_train_${i}.csv --id-prop-v relative_orbs/He_ref/80pzbaig_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 0 -e 50000 --ari "onehot" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	#top x orbs
	( jobname=59_pzb_cp2kgamma_top10_w100wd2e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80pzbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80pzbg_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	#pseudopot orbs s-p
	( jobname=60_pzb_cp2kgamma_pseudopot_w100wd2e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80pzbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80pzbg_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 0 -e 50000 --ari "potcarorb+eneg+hard+1hrow+block+1hvalence+wierd" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	#onehot only
	( jobname=61_pzb_cp2kgamma_onehotonly_w100wd2e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80pzbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80pzbg_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 0 -e 50000 --ari "onehot" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 
	
	#cgcnn
	( jobname=62_pzb_cp2kgamma_cgcnn_w100wd2e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80pzbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80pzbg_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 0 -e 50000 --ari "cgcnn" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	#cp2k occ 3
	( jobname=63_pzb_cp2kgamma_cp2ktop3_1hot_w100wd2e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80pzbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80pzbg_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 0 -e 50000 --ari "cp2ktop3_1hot" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	#s&p only
	( jobname=64_pzb_cp2kgamma_potcar_sponly_w100wd2e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80pzbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80pzbg_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 0 -e 50000 --ari "energy" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	#top x orbs occ only
	( jobname=65_pzb_cp2kgamma_top5_w100wd2e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80pzbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80pzbg_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 0 -e 50000 --ari "top5orb_n" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 
	
done