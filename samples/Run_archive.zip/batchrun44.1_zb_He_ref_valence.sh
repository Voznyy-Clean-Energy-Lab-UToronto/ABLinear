#!/bin/bash


for i in `seq 1 20`
do
		
	#1-7/2-6
	( jobname=68_zb_cp2kgamma_He_ref_valence_a1h2_w100wd2e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 0 -e 50000 --ari "He_ref_valence_atom1hot2" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	( jobname=69_zb_cp2kgamma_He_ref_valence_a1hped_w100wd2e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 0 -e 50000 --ari "He_ref_valence_atom1hot_ped" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 
	
done