#!/bin/bash


for i in `seq 1 20`
do
	
	#all
	( jobname=58_azb_cp2kgamma_He_ref_valence_a1h_w100wd2e-5_${i}_for; echo ${jobname}; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80azbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80azbg_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 0 -e 50000 --ari "He_ref_valence_atom1hot" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	( jobname=59_azb_cp2kgamma_He_ref_valence_gr1h_w100wd2e-5_${i}_for; echo ${jobname}; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80azbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80azbg_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 0 -e 50000 --ari "He_ref_valence_grouprow1hot" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 
	
	#1-7/2-6
	#( jobname=60_zb_cp2kgamma_He_ref_valence_a1h_w100wd2e-5_${i}_for; echo ${jobname}; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 0 -e 50000 --ari "He_ref_valence_atom1hot" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	#( jobname=61_zb_cp2kgamma_He_ref_valence_gr1h_w100wd2e-5_${i}_for; echo ${jobname}; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 0 -e 50000 --ari "He_ref_valence_grouprow1hot" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 
	
	#3-5
	( jobname=62_pzb_cp2kgamma_He_ref_valence_a1h_w100wd2e-5_${i}_for; echo ${jobname}; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80pzbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80pzbg_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 0 -e 50000 --ari "He_ref_valence_atom1hot" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	( jobname=63_pzb_cp2kgamma_He_ref_valence_gr1h_w100wd2e-5_${i}_for; echo ${jobname}; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80pzbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80pzbg_val_${i}.csv --out $jobname --width 100 --funnel 2 -m 0 -e 50000 --ari "He_ref_valence_grouprow1hot" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 
	
done