#!/bin/bash

declare -a targets=( "NaF" "MgO" "Na" "F" "Mg" "O" )

for i in "${targets[@]}"
do
	#current best
	( jobname=66_tbzb_ai_cp2kgamma_Herelorb_w100wd2e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/He_ref/tb_zbaig_${i}_t.csv --id-prop-v relative_orbs/He_ref/tb_zbaig_${i}_v.csv --out $jobname --width 100 --funnel 2 -m 0 -e 100000 --ari "onehot" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	( jobname=67_tbzb_ai_cp2kgamma_top10_w100wd2e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/He_ref/tb_zbaig_${i}_t.csv --id-prop-v relative_orbs/He_ref/tb_zbaig_${i}_v.csv --out $jobname --width 100 --funnel 2 -m 0 -e 100000 --ari "top10orb_n" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 
	
done