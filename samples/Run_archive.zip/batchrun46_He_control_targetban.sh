#!/bin/bash

declare -a targets=( "NaF" "MgO" "Na" "F" "Mg" "O" )

for i in "${targets[@]}"
do
	#current best
	( jobname=70_tbzb_ai_cp2kgamma_cgcnn_w100wd2e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/tb_zbaig_${i}_t.csv --id-prop-v relative_orbs/raw_input/tb_zbaig_${i}_v.csv --out $jobname --width 100 --funnel 2 -m 0 -e 100000 --ari "cgcnn" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	
	( jobname=71_tbzb_ai_cp2kgamma_onehot_w100wd2e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/tb_zbaig_${i}_t.csv --id-prop-v relative_orbs/raw_input/tb_zbaig_${i}_v.csv --out $jobname --width 100 --funnel 2 -m 0 -e 100000 --ari "onehot" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) 
	
done