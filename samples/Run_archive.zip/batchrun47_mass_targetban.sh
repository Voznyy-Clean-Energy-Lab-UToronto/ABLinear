#!/bin/bash

declare -a targets=( "Be" "Mg" "Ca" "Sr" "Ba" "Li" "Na" "K" "Rb" "Cs" "O" "F" "S" "Cl" "Se" "Br" "Te" "I" "Be_O" "Mg_O" "Ca_O" "Sr_O" "Ba_O" "Li_F" "Na_F" "K_F" "Rb_F" "Cs_F" "Be_S" "Mg_S" "Ca_S" "Sr_S" "Ba_S" "Li_Cl" "Na_Cl" "K_Cl" "Rb_Cl" "Cs_Cl" "Be_Se" "Mg_Se" "Ca_Se" "Sr_Se" "Ba_Se" "Li_Br" "Na_Br" "K_Br" "Rb_Br" "Cs_Br" "Be_Te" "Mg_Te" "Ca_Te" "Sr_Te" "Ba_Te" "Li_I" "Na_I" "K_I" "Rb_I" "Cs_I" )

for i in "${targets[@]}"
do
	
	( jobname=1_mtbzb_cp2kgamma_cgcnn_w100wd2e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/targetbans/tb_${i}_train.csv --id-prop-v relative_orbs/raw_input/targetbans/tb_${i}_val.csv --out core-ref_targetbans/$jobname --width 100 --funnel 2 -m 0 -e 100000 --ari "cgcnn" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/core-ref_targetbans/$jobname ) &
	
	( jobname=2_mtbzb_cp2kgamma_1hot_w100wd2e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/targetbans/tb_${i}_train.csv --id-prop-v relative_orbs/raw_input/targetbans/tb_${i}_val.csv --out core-ref_targetbans/$jobname --width 100 --funnel 2 -m 0 -e 100000 --ari "onehot" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/core-ref_targetbans/$jobname ) &
	
	( jobname=3_mtbzb_cp2kgamma_Heref1hot_w100wd2e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/He_ref/targetbans/tb_${i}_train.csv --id-prop-v relative_orbs/He_ref/targetbans/tb_${i}_val.csv --out core-ref_targetbans/$jobname --width 100 --funnel 2 -m 0 -e 100000 --ari "onehot" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/core-ref_targetbans/$jobname ) &
	
	( jobname=4_mtbzb_cp2kgamma_potcartop10_w100wd2e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/targetbans/tb_${i}_train.csv --id-prop-v relative_orbs/raw_input/targetbans/tb_${i}_val.csv --out core-ref_targetbans/$jobname --width 100 --funnel 2 -m 0 -e 100000 --ari "top10orb_n" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/core-ref_targetbans/$jobname ) 
	
done