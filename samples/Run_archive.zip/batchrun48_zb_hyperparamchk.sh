#!/bin/bash


for i in `seq 1 20`
do
	#top x orbs
	( jobname=72_zb_cp2kgamma_top10_w100wd2e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10orb_wd_drop/$jobname --width 100 --funnel 2 -m 0 -e 25000 --ari "top10orb_n" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10orb_wd_drop/$jobname ) &
	
	( jobname=73_zb_cp2kgamma_top10_w200wd2e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10orb_wd_drop/$jobname --width 200 --funnel 2 -m 0 -e 25000 --ari "top10orb_n" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10orb_wd_drop/$jobname ) &
	
	( jobname=74_zb_cp2kgamma_top10_w400wd2e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10orb_wd_drop/$jobname --width 400 --funnel 2 -m 0 -e 25000 --ari "top10orb_n" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10orb_wd_drop/$jobname ) &
	
	( jobname=75_zb_cp2kgamma_top10_w800wd2e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10orb_wd_drop/$jobname --width 800 --funnel 2 -m 0 -e 25000 --ari "top10orb_n" --lr 6e-3 --wd 2e-5  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10orb_wd_drop/$jobname )
	
	( jobname=76_zb_cp2kgamma_top10_w100wd2e-5d1e-1_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10orb_wd_drop/$jobname --width 100 --funnel 2 -m 0 -e 25000 --ari "top10orb_n" --lr 6e-3 --wd 2e-5 -d 0.1 > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10orb_wd_drop/$jobname ) &
	
	( jobname=77_zb_cp2kgamma_top10_w200wd2e-5d1e-1_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10orb_wd_drop/$jobname --width 200 --funnel 2 -m 0 -e 25000 --ari "top10orb_n" --lr 6e-3 --wd 2e-5 -d 0.1 > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10orb_wd_drop/$jobname ) &
	
	( jobname=78_zb_cp2kgamma_top10_w400wd2e-5d1e-1_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10orb_wd_drop/$jobname --width 400 --funnel 2 -m 0 -e 25000 --ari "top10orb_n" --lr 6e-3 --wd 2e-5 -d 0.1 > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10orb_wd_drop/$jobname ) &
	
	( jobname=79_zb_cp2kgamma_top10_w800wd2e-5d1e-1_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10orb_wd_drop/$jobname --width 800 --funnel 2 -m 0 -e 25000 --ari "top10orb_n" --lr 6e-3 --wd 2e-5 -d 0.1 > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10orb_wd_drop/$jobname )
	
	( jobname=80_zb_cp2kgamma_top10_w100wd2e-4_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10orb_wd_drop/$jobname --width 100 --funnel 2 -m 0 -e 25000 --ari "top10orb_n" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10orb_wd_drop/$jobname ) &
	
	( jobname=81_zb_cp2kgamma_top10_w200wd2e-4_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10orb_wd_drop/$jobname --width 200 --funnel 2 -m 0 -e 25000 --ari "top10orb_n" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10orb_wd_drop/$jobname ) &
	
	( jobname=82_zb_cp2kgamma_top10_w400wd2e-4_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10orb_wd_drop/$jobname --width 400 --funnel 2 -m 0 -e 25000 --ari "top10orb_n" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10orb_wd_drop/$jobname ) &
	
	( jobname=83_zb_cp2kgamma_top10_w800wd2e-4_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10orb_wd_drop/$jobname --width 800 --funnel 2 -m 0 -e 25000 --ari "top10orb_n" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10orb_wd_drop/$jobname )
	
	( jobname=84_zb_cp2kgamma_top10_w100wd2e-4d1e-1_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10orb_wd_drop/$jobname --width 100 --funnel 2 -m 0 -e 25000 --ari "top10orb_n" --lr 6e-3 --wd 2e-4 -d 0.1 > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10orb_wd_drop/$jobname ) &
	
	( jobname=85_zb_cp2kgamma_top10_w200wd2e-4d1e-1_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10orb_wd_drop/$jobname --width 200 --funnel 2 -m 0 -e 25000 --ari "top10orb_n" --lr 6e-3 --wd 2e-4 -d 0.1 > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10orb_wd_drop/$jobname ) &
	
	( jobname=86_zb_cp2kgamma_top10_w400wd2e-4d1e-1_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10orb_wd_drop/$jobname --width 400 --funnel 2 -m 0 -e 25000 --ari "top10orb_n" --lr 6e-3 --wd 2e-4 -d 0.1 > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10orb_wd_drop/$jobname ) &
	
	( jobname=87_zb_cp2kgamma_top10_w800wd2e-4d1e-1_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10orb_wd_drop/$jobname --width 800 --funnel 2 -m 0 -e 25000 --ari "top10orb_n" --lr 6e-3 --wd 2e-4 -d 0.1 > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10orb_wd_drop/$jobname )
	
done