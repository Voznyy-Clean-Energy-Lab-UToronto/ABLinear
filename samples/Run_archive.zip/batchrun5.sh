#!/bin/bash

for i in `seq 1 5`
do
	( jobname=overlap_block_partial${i}_enereneghard_w797_lr6e-3_lm; python3 ABlinear_nn.py . --id-prop-t synthdata_overlaps/block_train_partial${i}.csv --id-prop-v synthdata_overlaps/block_val.csv --out $jobname --width 797 --funnel 2 -m 8 -e 50000 --ari "+energy+eneg+hard" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &
	( jobname=overlap_block_partial${i}_enereneghard_w797_lr6e-3_for; python3 ABlinear_nn.py . --id-prop-t synthdata_overlaps/block_train_partial${i}.csv --id-prop-v synthdata_overlaps/block_val.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "+energy+eneg+hard" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )

done


