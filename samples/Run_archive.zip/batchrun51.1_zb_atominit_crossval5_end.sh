#!/bin/bash


for i in `seq 0 4`
do
	#current best
	( jobname=50_zb_ai_cp2kgamma_Herelorb_w1600wd2e-5d1e-1_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/He_ref/c-val/5_fold_zbaig_train_${i}.csv --id-prop-v relative_orbs/He_ref/c-val/5_fold_zbaig_val_${i}.csv --out he_ref_crossval/endpoint/$jobname --width 1600 --funnel 2 -m 0 -e 27650 --ari "onehot" --lr 6e-3 --wd 2e-5 -d 0.1  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/he_ref_crossval/endpoint/$jobname ) &
	
	#top x orbs
	( jobname=51_zb_cp2kgamma_top10_w1600wd2e-5d1e-1_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/c-val/5_fold_zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/c-val/5_fold_zbg_val_${i}.csv --out he_ref_crossval/endpoint/$jobname --width 1600 --funnel 2 -m 0 -e 1904 --ari "top10orb_n" --lr 6e-3 --wd 2e-5 -d 0.1  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/he_ref_crossval/endpoint/$jobname ) &
	
	#pseudopot orbs s-p
	( jobname=52_zb_cp2kgamma_pseudopot_w1600wd2e-5d1e-1_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/c-val/5_fold_zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/c-val/5_fold_zbg_val_${i}.csv --out he_ref_crossval/endpoint/$jobname --width 1600 --funnel 2 -m 0 -e 1037 --ari "potcarorb+eneg+hard+1hrow+block+1hvalence+wierd" --lr 6e-3 --wd 2e-5 -d 0.1  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/he_ref_crossval/endpoint/$jobname ) &
	
	#onehot only
	( jobname=53_zb_cp2kgamma_onehotonly_w1600wd2e-5d1e-1_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/c-val/5_fold_zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/c-val/5_fold_zbg_val_${i}.csv --out he_ref_crossval/endpoint/$jobname --width 1600 --funnel 2 -m 0 -e 7228 --ari "onehot" --lr 6e-3 --wd 2e-5 -d 0.1  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/he_ref_crossval/endpoint/$jobname ) 
	
	#cgcnn
	( jobname=54_zb_cp2kgamma_cgcnn_w1600wd2e-5d1e-1_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/c-val/5_fold_zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/c-val/5_fold_zbg_val_${i}.csv --out he_ref_crossval/endpoint/$jobname --width 1600 --funnel 2 -m 0 -e 34972 --ari "cgcnn" --lr 6e-3 --wd 2e-5 -d 0.1  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/he_ref_crossval/endpoint/$jobname ) &
	
	#cp2k occ 3
	( jobname=55_zb_cp2kgamma_cp2ktop3_1hot_w1600wd2e-5d1e-1_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/c-val/5_fold_zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/c-val/5_fold_zbg_val_${i}.csv --out he_ref_crossval/endpoint/$jobname --width 1600 --funnel 2 -m 0 -e 38636 --ari "cp2ktop3_1hot" --lr 6e-3 --wd 2e-5 -d 0.1  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/he_ref_crossval/endpoint/$jobname ) &
	
	#s&p only
	( jobname=56_zb_cp2kgamma_potcar_sponly_w1600wd2e-5d1e-1_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/c-val/5_fold_zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/c-val/5_fold_zbg_val_${i}.csv --out he_ref_crossval/endpoint/$jobname --width 1600 --funnel 2 -m 0 -e 45873 --ari "energy" --lr 6e-3 --wd 2e-5 -d 0.1  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/he_ref_crossval/endpoint/$jobname ) &
	
	#top x orbs occ only
	( jobname=57_zb_cp2kgamma_top5_w1600wd2e-5d1e-1_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/c-val/5_fold_zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/c-val/5_fold_zbg_val_${i}.csv --out he_ref_crossval/endpoint/$jobname --width 1600 --funnel 2 -m 0 -e 2757 --ari "top5orb_n" --lr 6e-3 --wd 2e-5 -d 0.1  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/he_ref_crossval/endpoint/$jobname ) 
	
done

for i in `seq 0 4`
do
	#current best
	( jobname=50_zb_ai_cp2kgamma_Herelorb_w1600wd2e-5d1e-1_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/He_ref/c-val/5_fold_zbaig_train_${i}.csv --id-prop-v relative_orbs/He_ref/c-val/5_fold_zbaig_val_${i}.csv --out he_ref_crossval/endpoint2/$jobname --width 1600 --funnel 2 -m 0 -e 27649 --ari "onehot" --lr 6e-3 --wd 2e-5 -d 0.1  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/he_ref_crossval/endpoint2/$jobname ) &
	
	#top x orbs
	( jobname=51_zb_cp2kgamma_top10_w1600wd2e-5d1e-1_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/c-val/5_fold_zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/c-val/5_fold_zbg_val_${i}.csv --out he_ref_crossval/endpoint2/$jobname --width 1600 --funnel 2 -m 0 -e 1903 --ari "top10orb_n" --lr 6e-3 --wd 2e-5 -d 0.1  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/he_ref_crossval/endpoint2/$jobname ) &
	
	#pseudopot orbs s-p
	( jobname=52_zb_cp2kgamma_pseudopot_w1600wd2e-5d1e-1_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/c-val/5_fold_zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/c-val/5_fold_zbg_val_${i}.csv --out he_ref_crossval/endpoint2/$jobname --width 1600 --funnel 2 -m 0 -e 1036 --ari "potcarorb+eneg+hard+1hrow+block+1hvalence+wierd" --lr 6e-3 --wd 2e-5 -d 0.1  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/he_ref_crossval/endpoint2/$jobname ) &
	
	#onehot only
	( jobname=53_zb_cp2kgamma_onehotonly_w1600wd2e-5d1e-1_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/c-val/5_fold_zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/c-val/5_fold_zbg_val_${i}.csv --out he_ref_crossval/endpoint2/$jobname --width 1600 --funnel 2 -m 0 -e 7227 --ari "onehot" --lr 6e-3 --wd 2e-5 -d 0.1  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/he_ref_crossval/endpoint2/$jobname ) 
	
	#cgcnn
	( jobname=54_zb_cp2kgamma_cgcnn_w1600wd2e-5d1e-1_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/c-val/5_fold_zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/c-val/5_fold_zbg_val_${i}.csv --out he_ref_crossval/endpoint2/$jobname --width 1600 --funnel 2 -m 0 -e 34971 --ari "cgcnn" --lr 6e-3 --wd 2e-5 -d 0.1  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/he_ref_crossval/endpoint2/$jobname ) &
	
	#cp2k occ 3
	( jobname=55_zb_cp2kgamma_cp2ktop3_1hot_w1600wd2e-5d1e-1_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/c-val/5_fold_zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/c-val/5_fold_zbg_val_${i}.csv --out he_ref_crossval/endpoint2/$jobname --width 1600 --funnel 2 -m 0 -e 38635 --ari "cp2ktop3_1hot" --lr 6e-3 --wd 2e-5 -d 0.1  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/he_ref_crossval/endpoint2/$jobname ) &
	
	#s&p only
	( jobname=56_zb_cp2kgamma_potcar_sponly_w1600wd2e-5d1e-1_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/c-val/5_fold_zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/c-val/5_fold_zbg_val_${i}.csv --out he_ref_crossval/endpoint2/$jobname --width 1600 --funnel 2 -m 0 -e 45872 --ari "energy" --lr 6e-3 --wd 2e-5 -d 0.1  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/he_ref_crossval/endpoint2/$jobname ) &
	
	#top x orbs occ only
	( jobname=57_zb_cp2kgamma_top5_w1600wd2e-5d1e-1_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/c-val/5_fold_zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/c-val/5_fold_zbg_val_${i}.csv --out he_ref_crossval/endpoint2/$jobname --width 1600 --funnel 2 -m 0 -e 2756 --ari "top5orb_n" --lr 6e-3 --wd 2e-5 -d 0.1  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/he_ref_crossval/endpoint2/$jobname ) 
	
done