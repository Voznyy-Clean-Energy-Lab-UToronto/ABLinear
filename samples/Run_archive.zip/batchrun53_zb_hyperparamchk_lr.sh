!/bin/bash


for i in `seq 1 20`
do
	( jobname=zb_cp2kgamma_top10_w1600wd2e-5lr6e-3_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10_lr_sgd/$jobname --width 1600 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-3 --wd 2e-5 -d 0.1 > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10_lr_sgd/$jobname ) &
	
	( jobname=zb_cp2kgamma_top10_w1600wd2e-5lr6e-4_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10_lr_sgd/$jobname --width 1600 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-4 --wd 2e-5 -d 0.1 > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10_lr_sgd/$jobname ) &
	
	( jobname=zb_cp2kgamma_top10_w1600wd2e-5lr6e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10_lr_sgd/$jobname --width 1600 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-5 --wd 2e-5 -d 0.1 > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10_lr_sgd/$jobname ) &
	
	( jobname=zb_cp2kgamma_top10_w1600wd2e-5lr6e-6_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10_lr_sgd/$jobname --width 1600 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-6 --wd 2e-5 -d 0.1 > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10_lr_sgd/$jobname ) 
	
	
	( jobname=zb_cp2kgamma_top10_w1600wd2e-4lr6e-3_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10_lr_sgd/$jobname --width 1600 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-3 --wd 2e-4 -d 0.1 > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10_lr_sgd/$jobname ) &
	
	( jobname=zb_cp2kgamma_top10_w1600wd2e-4lr6e-4_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10_lr_sgd/$jobname --width 1600 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-4 --wd 2e-4 -d 0.1 > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10_lr_sgd/$jobname ) &
	
	( jobname=zb_cp2kgamma_top10_w1600wd2e-4lr6e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10_lr_sgd/$jobname --width 1600 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-5 --wd 2e-4 -d 0.1 > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10_lr_sgd/$jobname ) &
	
	( jobname=zb_cp2kgamma_top10_w1600wd2e-4lr6e-6_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10_lr_sgd/$jobname --width 1600 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-6 --wd 2e-4 -d 0.1 > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10_lr_sgd/$jobname ) 
	
	###no anneal
	( jobname=zb_cp2kgamma_top10_na_w1600wd2e-5lr6e-3_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10_lr_sgd/$jobname --width 1600 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-3 --wd 2e-5 -d 0.1 --no-anneal > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10_lr_sgd/$jobname ) &
	
	( jobname=zb_cp2kgamma_top10_na_w1600wd2e-5lr6e-4_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10_lr_sgd/$jobname --width 1600 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-4 --wd 2e-5 -d 0.1 --no-anneal > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10_lr_sgd/$jobname ) &
	
	( jobname=zb_cp2kgamma_top10_na_w1600wd2e-5lr6e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10_lr_sgd/$jobname --width 1600 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-5 --wd 2e-5 -d 0.1 --no-anneal > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10_lr_sgd/$jobname ) &
	
	( jobname=zb_cp2kgamma_top10_na_w1600wd2e-5lr6e-6_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10_lr_sgd/$jobname --width 1600 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-6 --wd 2e-5 -d 0.1 --no-anneal > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10_lr_sgd/$jobname ) 
	
	
	( jobname=zb_cp2kgamma_top10_na_w1600wd2e-4lr6e-3_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10_lr_sgd/$jobname --width 1600 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-3 --wd 2e-4 -d 0.1 --no-anneal > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10_lr_sgd/$jobname ) &
	
	( jobname=zb_cp2kgamma_top10_na_w1600wd2e-4lr6e-4_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10_lr_sgd/$jobname --width 1600 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-4 --wd 2e-4 -d 0.1 --no-anneal > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10_lr_sgd/$jobname ) &
	
	( jobname=zb_cp2kgamma_top10_na_w1600wd2e-4lr6e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10_lr_sgd/$jobname --width 1600 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-5 --wd 2e-4 -d 0.1 --no-anneal > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10_lr_sgd/$jobname ) &
	
	( jobname=zb_cp2kgamma_top10_na_w1600wd2e-4lr6e-6_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10_lr_sgd/$jobname --width 1600 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-6 --wd 2e-4 -d 0.1 --no-anneal > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10_lr_sgd/$jobname ) 
	
	##sgd
	
	( jobname=zb_cp2kgamma_top10_sgd_w1600wd2e-5lr6e-3_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10_sgd_lr_sgd/$jobname --width 1600 --funnel 2 -m 0 -e 1000 --ari "top10orb_n" --lr 6e-3 --wd 2e-5 -d 0.1 --sgd > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10_sgd_lr_sgd/$jobname ) &
	
	( jobname=zb_cp2kgamma_top10_sgd_w1600wd2e-5lr6e-4_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10_sgd_lr_sgd/$jobname --width 1600 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-4 --wd 2e-5 -d 0.1 --sgd > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10_sgd_lr_sgd/$jobname ) &
	
	( jobname=zb_cp2kgamma_top10_sgd_w1600wd2e-5lr6e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10_sgd_lr_sgd/$jobname --width 1600 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-5 --wd 2e-5 -d 0.1 --sgd > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10_sgd_lr_sgd/$jobname ) &
	
	( jobname=zb_cp2kgamma_top10_sgd_w1600wd2e-5lr6e-6_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10_sgd_lr_sgd/$jobname --width 1600 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-6 --wd 2e-5 -d 0.1 --sgd > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10_sgd_lr_sgd/$jobname ) 
	
	
	( jobname=zb_cp2kgamma_top10_sgd_w1600wd2e-4lr6e-3_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10_sgd_lr_sgd/$jobname --width 1600 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-3 --wd 2e-4 -d 0.1 --sgd > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10_sgd_lr_sgd/$jobname ) &
	
	( jobname=zb_cp2kgamma_top10_sgd_w1600wd2e-4lr6e-4_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10_sgd_lr_sgd/$jobname --width 1600 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-4 --wd 2e-4 -d 0.1 --sgd > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10_sgd_lr_sgd/$jobname ) &
	
	( jobname=zb_cp2kgamma_top10_sgd_w1600wd2e-4lr6e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10_sgd_lr_sgd/$jobname --width 1600 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-5 --wd 2e-4 -d 0.1 --sgd > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10_sgd_lr_sgd/$jobname ) &
	
	( jobname=zb_cp2kgamma_top10_sgd_w1600wd2e-4lr6e-6_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10_sgd_lr_sgd/$jobname --width 1600 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-6 --wd 2e-4 -d 0.1 --sgd > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10_sgd_lr_sgd/$jobname ) 
	
	###no anneal
	( jobname=zb_cp2kgamma_top10_sgd_na_w1600wd2e-5lr6e-3_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10_sgd_lr_sgd/$jobname --width 1600 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-3 --wd 2e-5 -d 0.1 --sgd --no-anneal > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10_sgd_lr_sgd/$jobname ) &
	
	( jobname=zb_cp2kgamma_top10_sgd_na_w1600wd2e-5lr6e-4_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10_sgd_lr_sgd/$jobname --width 1600 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-4 --wd 2e-5 -d 0.1 --sgd --no-anneal > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10_sgd_lr_sgd/$jobname ) &
	
	( jobname=zb_cp2kgamma_top10_sgd_na_w1600wd2e-5lr6e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10_sgd_lr_sgd/$jobname --width 1600 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-5 --wd 2e-5 -d 0.1 --sgd --no-anneal > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10_sgd_lr_sgd/$jobname ) &
	
	( jobname=zb_cp2kgamma_top10_sgd_na_w1600wd2e-5lr6e-6_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10_sgd_lr_sgd/$jobname --width 1600 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-6 --wd 2e-5 -d 0.1 --sgd --no-anneal > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10_sgd_lr_sgd/$jobname ) 
	
	
	( jobname=zb_cp2kgamma_top10_sgd_na_w1600wd2e-4lr6e-3_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10_sgd_lr_sgd/$jobname --width 1600 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-3 --wd 2e-4 -d 0.1 --sgd --no-anneal > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10_sgd_lr_sgd/$jobname ) &
	
	( jobname=zb_cp2kgamma_top10_sgd_na_w1600wd2e-4lr6e-4_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10_sgd_lr_sgd/$jobname --width 1600 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-4 --wd 2e-4 -d 0.1 --sgd --no-anneal > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10_sgd_lr_sgd/$jobname ) &
	
	( jobname=zb_cp2kgamma_top10_sgd_na_w1600wd2e-4lr6e-5_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10_sgd_lr_sgd/$jobname --width 1600 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-5 --wd 2e-4 -d 0.1 --sgd --no-anneal > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10_sgd_lr_sgd/$jobname ) &
	
	( jobname=zb_cp2kgamma_top10_sgd_na_w1600wd2e-4lr6e-6_${i}_for; python3 ABlinear_nn.py . --id-prop-t relative_orbs/raw_input/80zbg_train_${i}.csv --id-prop-v relative_orbs/raw_input/80zbg_val_${i}.csv --out top10_sgd_lr_sgd/$jobname --width 1600 --funnel 2 -m 0 -e 50000 --ari "top10orb_n" --lr 6e-6 --wd 2e-4 -d 0.1 --sgd --no-anneal > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/top10_sgd_lr_sgd/$jobname ) 
	
done