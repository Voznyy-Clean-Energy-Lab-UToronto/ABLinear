#!/bin/bash

outfold=component_linearity_check
infold=quasilinear_components
offset=28

declare -a targets=(  "etot_ae" "eform_ae" ) #"pin" "etoteform" "ponly"
declare -a ntarg=( 1 1 ) #8 2 6

for j in "${!targets[@]}"
do
	for i in `seq 0 4`
	do
		#current best
		( jobname=$((${j} + ${offset}))_zb_${targets[$j]}_cgcnn_linearcheck_w400lr1e-4wd2e-4d1e-1_${i}_for; echo $jobname; python3 ABlinear_multi.py . --id-prop-t $infold/5_fold_zb_${targets[$j]}_train_${i}.csv --id-prop-v $infold/5_fold_zb_${targets[$j]}_val_${i}.csv --out $outfold/$jobname --width 400 --funnel 4 -m 0 -e 50000 --ari "cgcnn" --lr 1e-4 --wd 2e-4 -d 0.1 --ntarg ${ntarg[$j]} > ${jobname}.txt; python train_outputs/fastplot_multi.py train_outputs/$outfold/$jobname ) &
		
	done
	wait $(jobs -p)
	
	((offset++))
	
	for i in `seq 0 4`
	do
		#current best
		( jobname=$((${j} + ${offset}))_zb_${targets[$j]}_1hot_linearcheck_w400lr1e-4wd2e-4d1e-1_${i}_for; echo $jobname; python3 ABlinear_multi.py . --id-prop-t $infold/5_fold_zb_${targets[$j]}_train_${i}.csv --id-prop-v $infold/5_fold_zb_${targets[$j]}_val_${i}.csv --out $outfold/$jobname --width 400 --funnel 4 -m 0 -e 50000 --ari "onehot" --lr 1e-4 --wd 2e-4 -d 0.1 --ntarg ${ntarg[$j]} > ${jobname}.txt; python train_outputs/fastplot_multi.py train_outputs/$outfold/$jobname ) &
	done
	wait $(jobs -p)
	
	((offset++))
	
	for i in `seq 0 4`
	do
		#current best
		( jobname=$((${j} + ${offset}))_zb_${targets[$j]}_1hotgr_linearcheck_w400lr1e-4wd2e-4d1e-1_${i}_for; echo $jobname; python3 ABlinear_multi.py . --id-prop-t $infold/5_fold_zb_${targets[$j]}_train_${i}.csv --id-prop-v $infold/5_fold_zb_${targets[$j]}_val_${i}.csv --out $outfold/$jobname --width 400 --funnel 4 -m 0 -e 50000 --ari "1hgroup_1hrow_ionic" --lr 1e-4 --wd 2e-4 -d 0.1 --ntarg ${ntarg[$j]} > ${jobname}.txt; python train_outputs/fastplot_multi.py train_outputs/$outfold/$jobname ) &
	done
	wait $(jobs -p)
done
