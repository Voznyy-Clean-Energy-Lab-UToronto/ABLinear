#!/bin/bash

outfold=component_linearity_check
infold=quasilinear_components
offset=12

declare -a targets=(  "etoteform_p" "etot_p" ) #"pin" "etoteform" "ponly"
declare -a ntarg=( 2 1 ) #8 2 6

for j in "${!targets[@]}"
do
	for i in `seq 0 4`
	do
		#current best
		( jobname=$((${j} + ${offset}))_zb_${targets[$j]}_1hgr_linearcheck_w400lr6e-3wd2e-4d1e-1_${i}_for; echo $jobname; python3 ABlinear_multi.py . --id-prop-t $infold/5_fold_zb_${targets[$j]}_train_${i}.csv --id-prop-v $infold/5_fold_zb_${targets[$j]}_val_${i}.csv --out $outfold/$jobname --width 400 --funnel 4 -m 0 -e 50000 --ari "1hgroup_1hrow_ionic" --lr 6e-3 --wd 2e-4 -d 0.1 --ntarg ${ntarg[$j]} > ${jobname}.txt; python train_outputs/fastplot_multi.py train_outputs/$outfold/$jobname ) &
		
	done
	#wait $(jobs -p)
	
	((offset++))
	
	for i in `seq 0 4`
	do
		#current best
		( jobname=$((${j} + ${offset}))_zb_${targets[$j]}_1hot_linearcheck_w400lr6e-3wd2e-4d1e-1_${i}_for; echo $jobname; python3 ABlinear_multi.py . --id-prop-t $infold/5_fold_zb_${targets[$j]}_train_${i}.csv --id-prop-v $infold/5_fold_zb_${targets[$j]}_val_${i}.csv --out $outfold/$jobname --width 400 --funnel 4 -m 0 -e 50000 --ari "onehot" --lr 6e-3 --wd 2e-4 -d 0.1 --ntarg ${ntarg[$j]} > ${jobname}.txt; python train_outputs/fastplot_multi.py train_outputs/$outfold/$jobname ) &
	done
	wait $(jobs -p)
done
