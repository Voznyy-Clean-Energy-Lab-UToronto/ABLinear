#!/bin/bash
# 3 rules with synthetic data comparisons

( jobname=mpoverlap_rsonly_3_for; python3 ABlinear_nn.py . --id-prop-t synthdata_overlaps/rszb_mp/train_rsonly_3.csv --id-prop-v synthdata_overlaps/rszb_mp/val_rsonly_3.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "+energy+eneg+hard" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

( jobname=mpoverlap_zb1_3_for; python3 ABlinear_nn.py . --id-prop-t synthdata_overlaps/rszb_mp/train_mpzb1_3.csv --id-prop-v synthdata_overlaps/rszb_mp/val_rsonly_3.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "+energy+eneg+hard" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

( jobname=mpoverlap_zb2_3_for; python3 ABlinear_nn.py . --id-prop-t synthdata_overlaps/rszb_mp/train_mpzb2_3.csv --id-prop-v synthdata_overlaps/rszb_mp/val_rsonly_3.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "+energy+eneg+hard" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

( jobname=mpoverlap_matprojzb_3_for; python3 ABlinear_nn.py . --id-prop-t synthdata_overlaps/rszb_mp/train_mpzb_all_3.csv --id-prop-v synthdata_overlaps/rszb_mp/val_rsonly_3.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "+energy+eneg+hard" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

( jobname=mpoverlap_zb_allcombs_3_for; python3 ABlinear_nn.py . --id-prop-t synthdata_overlaps/rszb_mp/train_zb_allcombs_3.csv --id-prop-v synthdata_overlaps/rszb_mp/val_rsonly_3.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "+energy+eneg+hard" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )


( jobname=mpoverlap_rsonly_4_for; python3 ABlinear_nn.py . --id-prop-t synthdata_overlaps/rszb_mp/train_rsonly_4.csv --id-prop-v synthdata_overlaps/rszb_mp/val_rsonly_4.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "+energy+eneg+hard" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

( jobname=mpoverlap_zb1_4_for; python3 ABlinear_nn.py . --id-prop-t synthdata_overlaps/rszb_mp/train_mpzb1_4.csv --id-prop-v synthdata_overlaps/rszb_mp/val_rsonly_4.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "+energy+eneg+hard" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

( jobname=mpoverlap_zb2_4_for; python3 ABlinear_nn.py . --id-prop-t synthdata_overlaps/rszb_mp/train_mpzb2_4.csv --id-prop-v synthdata_overlaps/rszb_mp/val_rsonly_4.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "+energy+eneg+hard" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

( jobname=mpoverlap_matprojzb_4_for; python3 ABlinear_nn.py . --id-prop-t synthdata_overlaps/rszb_mp/train_mpzb_all_4.csv --id-prop-v synthdata_overlaps/rszb_mp/val_rsonly_4.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "+energy+eneg+hard" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

( jobname=mpoverlap_zb_allcombs_4_for; python3 ABlinear_nn.py . --id-prop-t synthdata_overlaps/rszb_mp/train_zb_allcombs_4.csv --id-prop-v synthdata_overlaps/rszb_mp/val_rsonly_4.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "+energy+eneg+hard" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )

( jobname=mpoverlap_rsonly_5_for; python3 ABlinear_nn.py . --id-prop-t synthdata_overlaps/rszb_mp/train_rsonly_5.csv --id-prop-v synthdata_overlaps/rszb_mp/val_rsonly_5.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "+energy+eneg+hard" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

( jobname=mpoverlap_zb1_5_for; python3 ABlinear_nn.py . --id-prop-t synthdata_overlaps/rszb_mp/train_mpzb1_5.csv --id-prop-v synthdata_overlaps/rszb_mp/val_rsonly_5.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "+energy+eneg+hard" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

( jobname=mpoverlap_zb2_5_for; python3 ABlinear_nn.py . --id-prop-t synthdata_overlaps/rszb_mp/train_mpzb2_5.csv --id-prop-v synthdata_overlaps/rszb_mp/val_rsonly_5.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "+energy+eneg+hard" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

( jobname=mpoverlap_matprojzb_5_for; python3 ABlinear_nn.py . --id-prop-t synthdata_overlaps/rszb_mp/train_mpzb_all_5.csv --id-prop-v synthdata_overlaps/rszb_mp/val_rsonly_5.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "+energy+eneg+hard" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

( jobname=mpoverlap_zb_allcombs_5_for; python3 ABlinear_nn.py . --id-prop-t synthdata_overlaps/rszb_mp/train_zb_allcombs_5.csv --id-prop-v synthdata_overlaps/rszb_mp/val_rsonly_5.csv --out $jobname --width 797 --funnel 2 -m 0 -e 50000 --ari "+energy+eneg+hard" --lr 6e-3 --wd 2e-4  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )