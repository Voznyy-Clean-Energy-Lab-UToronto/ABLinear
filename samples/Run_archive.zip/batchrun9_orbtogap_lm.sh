#!/bin/bash

( jobname=rocksalt_dsplit0_spvalrowblock_lrlo_wdhi_allcombs; python3 ABlinear_nn.py . --id-prop-t rocksalts/dsplit/d0_rs.csv --id-prop-v rocksalts/dsplit/d0_rs.csv --out $jobname --width 797 --funnel 2 -m 8 -e 50000 --ari "sp+valence1hot+row+block" --lr 1e-6 --wd 1e-3  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

( jobname=zincblende_dsplit0_spvalrowblock_lrlo_wdhi_allcombs; python3 ABlinear_nn.py . --id-prop-t rocksalts/dsplit/d0_zb.csv --id-prop-v rocksalts/dsplit/d0_zb.csv --out $jobname --width 797 --funnel 2 -m 8 -e 50000 --ari "sp+valence1hot+row+block" --lr 1e-6 --wd 1e-3  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )

( jobname=rocksalt_dsplit1_spvalrowblock_lrlo_wdhi_allcombs; python3 ABlinear_nn.py . --id-prop-t rocksalts/dsplit/d1_rs.csv --id-prop-v rocksalts/dsplit/d1_rs.csv --out $jobname --width 797 --funnel 2 -m 8 -e 50000 --ari "sp+valence1hot+row+block" --lr 1e-6 --wd 1e-3  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

( jobname=zincblende_dsplit1_spvalrowblock_lrlo_wdhi_allcombs; python3 ABlinear_nn.py . --id-prop-t rocksalts/dsplit/d1_zb.csv --id-prop-v rocksalts/dsplit/d1_zb.csv --out $jobname --width 797 --funnel 2 -m 8 -e 50000 --ari "sp+valence1hot+row+block" --lr 1e-6 --wd 1e-3  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )

( jobname=rocksalt_dsplit2_spvalrowblock_lrlo_wdhi_allcombs; python3 ABlinear_nn.py . --id-prop-t rocksalts/dsplit/d2_rs.csv --id-prop-v rocksalts/dsplit/d2_rs.csv --out $jobname --width 797 --funnel 2 -m 8 -e 50000 --ari "sp+valence1hot+row+block" --lr 1e-6 --wd 1e-3  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname ) &

( jobname=zincblende_dsplit2_spvalrowblock_lrlo_wdhi_allcombs; python3 ABlinear_nn.py . --id-prop-t rocksalts/dsplit/d2_zb.csv --id-prop-v rocksalts/dsplit/d2_zb.csv --out $jobname --width 797 --funnel 2 -m 8 -e 50000 --ari "sp+valence1hot+row+block" --lr 1e-6 --wd 1e-3  > ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )


( jobname=rocksalt_dsplit0_spvalrowblock_lrlo_wdhi_allcombs; python3 ABlinear_pred.py . --id-prop-p rocksalts/dsplit/d0_rst.csv --out $jobname --width 797 --funnel 2 -m 8 --ari "sp+valence1hot+row+block"  >> ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )

( jobname=zincblende_dsplit0_spvalrowblock_lrlo_wdhi_allcombs; python3 ABlinear_pred.py . --id-prop-p rocksalts/dsplit/d0.csv --out $jobname --width 797 --funnel 2 -m 8 --ari "sp+valence1hot+row+block"  >> ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )

( jobname=rocksalt_dsplit1_spvalrowblock_lrlo_wdhi_allcombs; python3 ABlinear_pred.py . --id-prop-p rocksalts/dsplit/d1_rst.csv --out $jobname --width 797 --funnel 2 -m 8 --ari "sp+valence1hot+row+block"  >> ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )

( jobname=zincblende_dsplit1_spvalrowblock_lrlo_wdhi_allcombs; python3 ABlinear_pred.py . --id-prop-p rocksalts/dsplit/d1.csv --out $jobname --width 797 --funnel 2 -m 8 --ari "sp+valence1hot+row+block"  >> ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )

( jobname=rocksalt_dsplit2_spvalrowblock_lrlo_wdhi_allcombs; python3 ABlinear_pred.py . --id-prop-p rocksalts/dsplit/d2_rst.csv --out $jobname --width 797 --funnel 2 -m 8 --ari "sp+valence1hot+row+block"  >> ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )

( jobname=zincblende_dsplit2_spvalrowblock_lrlo_wdhi_allcombs; python3 ABlinear_pred.py . --id-prop-p rocksalts/dsplit/d2.csv --out $jobname --width 797 --funnel 2 -m 8 --ari "sp+valence1hot+row+block"  >> ${jobname}.txt; python train_outputs/fastplot.py train_outputs/$jobname )